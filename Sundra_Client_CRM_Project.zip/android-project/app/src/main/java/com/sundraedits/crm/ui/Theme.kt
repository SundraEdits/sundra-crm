package com.sundraedits.crm.ui

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

val Ivory = Color(0xFFF5F0E6)
val Cream = Color(0xFFEAE0D0)
val Champagne = Color(0xFFD8C8AD)
val Sage = Color(0xFFE5E7D9)
val Gold = Color(0xFFA18455)
val Taupe = Color(0xFF8B7B65)
val Ink = Color(0xFF514637)
val Danger = Color(0xFF9C4A3C) // muted brick, used only for overdue / destructive cues

private val Scheme = lightColorScheme(
    primary = Gold,
    onPrimary = Color.White,
    primaryContainer = Champagne,
    onPrimaryContainer = Ink,
    secondary = Taupe,
    onSecondary = Color.White,
    secondaryContainer = Sage,
    onSecondaryContainer = Ink,
    tertiary = Taupe,
    background = Ivory,
    onBackground = Ink,
    surface = Ivory,
    onSurface = Ink,
    surfaceVariant = Cream,
    onSurfaceVariant = Taupe,
    surfaceTint = Gold,
    surfaceContainerLowest = Ivory,
    surfaceContainerLow = Ivory,
    surfaceContainer = Ivory,
    surfaceContainerHigh = Ivory,
    surfaceContainerHighest = Cream,
    outline = Champagne,
    outlineVariant = Champagne,
    error = Danger,
    onError = Color.White
)

private val Base = Typography()
private val AppTypography = Typography(
    headlineLarge = Base.headlineLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
    headlineMedium = Base.headlineMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
    headlineSmall = Base.headlineSmall.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
    titleLarge = Base.titleLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold)
)

@Composable
fun SundraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = AppTypography) {
        CompositionLocalProvider(LocalContentColor provides Ink) { content() }
    }
}
