package com.sundraedits.crm.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sundraedits.crm.data.Client
import com.sundraedits.crm.data.ClientStatus
import com.sundraedits.crm.data.Service
import com.sundraedits.crm.util.Dates
import com.sundraedits.crm.util.Launch

@Composable
fun ClientsScreen(vm: CrmViewModel, onOpen: (Long) -> Unit, onEdit: (Long) -> Unit) {
    val clients by vm.clients.collectAsState()
    val cc by vm.countryCode.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    var svc by rememberSaveable { mutableStateOf<Service?>(null) }
    var st by rememberSaveable { mutableStateOf<ClientStatus?>(null) }
    var sortAlpha by rememberSaveable { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Clients", subtitle = "SUNDRA EDITS")
        val list = clients
        if (list == null) {
            LoadingBox()
        } else {
            val q = query.trim()
            val qDigits = q.filter { it.isDigit() }
            val filtered = remember(list, q, svc, st, sortAlpha) {
                list.filter { c ->
                    (svc == null || c.service == svc) &&
                        (st == null || c.status == st) &&
                        (q.isEmpty() ||
                            c.name.contains(q, ignoreCase = true) ||
                            c.instagram.contains(q.removePrefix("@"), ignoreCase = true) ||
                            c.phone.contains(q) ||
                            (qDigits.isNotEmpty() && c.phone.filter { it.isDigit() }.contains(qDigits)))
                }.let { r ->
                    if (sortAlpha) r.sortedBy { it.name.lowercase() }
                    else r.sortedWith(compareByDescending<Client> { it.contactDate }.thenByDescending { it.createdAt })
                }
            }
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassField(query, { query = it }, "Search name, phone or Instagram", trailing = { Icon(Icons.Default.Search, contentDescription = null, tint = Gold) })
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Latest contacted", !sortAlpha) { sortAlpha = false }
                    Chip("A\u2013Z", sortAlpha) { sortAlpha = true }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("All services", svc == null) { svc = null }
                    Service.values().forEach { s -> Chip(s.short, svc == s) { svc = s } }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("All statuses", st == null) { st = null }
                    ClientStatus.values().forEach { s -> Chip(s.label, st == s) { st = s } }
                }
                Text("${filtered.size} of ${list.size} clients", fontSize = 12.sp, color = Taupe)
            }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = ListPadding, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (list.isEmpty()) item { EmptyState("No clients yet. Use the + button to add your first client.") }
                else if (filtered.isEmpty()) item { EmptyState("No clients match your search or filters.") }
                items(filtered, key = { it.id }) { c -> ClientCard(c, cc, { onOpen(c.id) }, { onEdit(c.id) }) }
            }
        }
    }
}

@Composable
fun ClientCard(c: Client, cc: String, onOpen: () -> Unit, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    GlassCard(Modifier.fillMaxWidth(), onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(c.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(c.phone + if (c.city.isNotBlank()) " \u00B7 ${c.city}" else "", fontSize = 12.sp, color = Taupe, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.padding(start = 8.dp))
            StatusChip(c.status)
        }
        Text("${c.service.short} \u00B7 Contacted ${Dates.date(c.contactDate)}", fontSize = 12.sp, color = Taupe, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundAction(Icons.Default.Send, "Open WhatsApp") { Launch.whatsApp(ctx, c.phone, cc) }
            RoundAction(Icons.Default.Call, "Call") { Launch.dial(ctx, c.phone) }
            if (c.instagram.isNotBlank()) TextPill("Instagram") { Launch.instagram(ctx, c.instagram) }
            RoundAction(Icons.Default.Edit, "Edit client", onEdit)
        }
    }
}
