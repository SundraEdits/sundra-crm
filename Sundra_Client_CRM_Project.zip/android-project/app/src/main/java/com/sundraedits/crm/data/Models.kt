package com.sundraedits.crm.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class Service(val label: String, val short: String, val tagline: String) {
    SOCIAL("Social Media Management", "Social Media", "Content planning, posting and growth"),
    VIDEO(
        "Instagram Video Editing / Reels Editing / Professional Video Shoot",
        "Video & Reels",
        "Reels, edits and professional shoots"
    ),
    WEB("Website Development", "Website", "Design and build of a brand website")
}

enum class ClientStatus(val label: String) {
    CONTACTED("Contacted"),
    REPLY_RECEIVED("Reply Received"),
    WORK_DISCUSSION("Work Discussion"),
    CONFIRMED("Confirmed Client"),
    COMPLETED("Completed"),
    CLOSED("Closed / Not Interested")
}

enum class ProjectStatus(val label: String) {
    PENDING("Pending"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed")
}

enum class ActivityType { CREATED, MESSAGE, REPLY, STATUS, FOLLOWUP, FOLLOWUP_DONE, NOTES, PROJECT, UPDATED }

@Entity(tableName = "clients")
data class Client(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val instagram: String = "",
    val city: String = "",
    val service: Service = Service.SOCIAL,
    val contactDate: Long,
    val messageSent: Boolean = false,
    val status: ClientStatus = ClientStatus.CONTACTED,
    val notes: String = "",
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
    val repliedAt: Long? = null,
    val confirmedAt: Long? = null,
    val completedAt: Long? = null,
    val projectAmount: String = "",
    val projectNotes: String = "",
    val projectStatus: ProjectStatus = ProjectStatus.PENDING
)

@Entity(
    tableName = "followups",
    foreignKeys = [ForeignKey(
        entity = Client::class,
        parentColumns = ["id"],
        childColumns = ["clientId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("clientId")]
)
data class FollowUp(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    val dueDate: Long,
    val notes: String = "",
    val completed: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = 0
)

@Entity(
    tableName = "activities",
    foreignKeys = [ForeignKey(
        entity = Client::class,
        parentColumns = ["id"],
        childColumns = ["clientId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("clientId")]
)
data class Activity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    val type: ActivityType,
    val description: String,
    val timestamp: Long
)
