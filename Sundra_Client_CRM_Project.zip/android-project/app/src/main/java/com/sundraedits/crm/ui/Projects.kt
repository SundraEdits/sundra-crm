package com.sundraedits.crm.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sundraedits.crm.data.Client
import com.sundraedits.crm.data.ClientStatus
import com.sundraedits.crm.data.ProjectStatus
import com.sundraedits.crm.util.Dates
import com.sundraedits.crm.util.Launch

@Composable
fun ProjectsScreen(vm: CrmViewModel, onOpen: (Long) -> Unit) {
    val clients by vm.clients.collectAsState()
    val cc by vm.countryCode.collectAsState()
    var tab by rememberSaveable { mutableStateOf(0) }
    var editId by rememberSaveable { mutableStateOf<Long?>(null) }
    val ctx = LocalContext.current

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Projects", subtitle = "SUNDRA EDITS")
        val list = clients
        if (list == null) {
            LoadingBox()
        } else {
            val active = list.filter { it.status == ClientStatus.CONFIRMED }.sortedByDescending { it.confirmedAt ?: 0L }
            val completed = list.filter { it.status == ClientStatus.COMPLETED }.sortedByDescending { it.completedAt ?: 0L }
            Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Confirmed (${active.size})", tab == 0) { tab = 0 }
                Chip("Completed (${completed.size})", tab == 1) { tab = 1 }
            }
            val shown = if (tab == 0) active else completed
            LazyColumn(Modifier.fillMaxSize(), contentPadding = ListPadding, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (shown.isEmpty()) item {
                    EmptyState(if (tab == 0) "No confirmed projects yet. Set a client's status to Confirmed Client and it appears here." else "No completed projects yet.")
                }
                items(shown, key = { it.id }) { c ->
                    ProjectCard(
                        c,
                        onOpen = { onOpen(c.id) },
                        onWhatsApp = { Launch.whatsApp(ctx, c.phone, cc) },
                        onEdit = { editId = c.id },
                        onStatus = { ps -> vm.updateProject(c.id, c.projectAmount, c.projectNotes, ps) }
                    )
                }
            }
            val editing = list.firstOrNull { it.id == editId }
            if (editing != null) {
                ProjectDialog(editing, { amt, notes, ps -> vm.updateProject(editing.id, amt, notes, ps); editId = null }, { editId = null })
            }
        }
    }
}

@Composable
private fun ProjectCard(c: Client, onOpen: () -> Unit, onWhatsApp: () -> Unit, onEdit: () -> Unit, onStatus: (ProjectStatus) -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(c.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(c.service.short, fontSize = 12.sp, color = Taupe)
            }
            RoundAction(Icons.Default.Send, "Open WhatsApp", onWhatsApp)
            Spacer(Modifier.padding(start = 8.dp))
            RoundAction(Icons.Default.Edit, "Edit project", onEdit)
        }
        Spacer(Modifier.height(8.dp))
        InfoRow("WhatsApp", c.phone)
        InfoRow("Confirmed", c.confirmedAt?.let { Dates.date(it) } ?: "\u2014")
        InfoRow("Amount", c.projectAmount.ifBlank { "\u2014" })
        if (c.projectNotes.isNotBlank()) InfoRow("Notes", c.projectNotes)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ProjectStatus.values().forEach { ps -> Chip(ps.label, c.projectStatus == ps) { onStatus(ps) } }
        }
    }
}

@Composable
fun ProjectDialog(c: Client, onSave: (String, String, ProjectStatus) -> Unit, onDismiss: () -> Unit) {
    var amount by remember(c.id) { mutableStateOf(c.projectAmount) }
    var notes by remember(c.id) { mutableStateOf(c.projectNotes) }
    var ps by remember(c.id) { mutableStateOf(c.projectStatus) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ivory,
        title = { Text("Project \u2014 ${c.name}", color = Ink) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassField(amount, { amount = it }, "Project amount (optional)", keyboardType = KeyboardType.Text)
                GlassField(notes, { notes = it }, "Project notes", singleLine = false, minLines = 3)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProjectStatus.values().forEach { p -> Chip(p.label, ps == p) { ps = p } }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(amount.trim(), notes.trim(), ps) }) { Text("Save", color = Gold, fontWeight = FontWeight.SemiBold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Taupe) } }
    )
}
