package com.sundraedits.crm.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.sundraedits.crm.data.Client
import com.sundraedits.crm.data.Service
import com.sundraedits.crm.util.Dates
import com.sundraedits.crm.util.Phone

@Composable
fun ClientFormScreen(vm: CrmViewModel, clientId: Long?, onBack: () -> Unit, onSaved: (Long) -> Unit) {
    val clients by vm.clients.collectAsState()
    val loaded = clients
    val existing = if (clientId != null) loaded?.firstOrNull { it.id == clientId } else null
    if (clientId != null && existing == null) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("Edit Client", onBack = onBack)
            LoadingBox()
        }
    } else {
        ClientForm(vm, existing, onBack, onSaved)
    }
}

@Composable
private fun ClientForm(vm: CrmViewModel, existing: Client?, onBack: () -> Unit, onSaved: (Long) -> Unit) {
    var name by rememberSaveable { mutableStateOf(existing?.name ?: "") }
    var phone by rememberSaveable { mutableStateOf(existing?.phone ?: "") }
    var instagram by rememberSaveable { mutableStateOf(existing?.instagram ?: "") }
    var city by rememberSaveable { mutableStateOf(existing?.city ?: "") }
    var service by rememberSaveable { mutableStateOf<Service?>(existing?.service) }
    var contactDate by rememberSaveable { mutableStateOf(existing?.contactDate ?: Dates.today()) }
    var messageSent by rememberSaveable { mutableStateOf(existing?.messageSent ?: false) }
    var followUp by rememberSaveable { mutableStateOf<Long?>(null) }
    var notes by rememberSaveable { mutableStateOf(existing?.notes ?: "") }
    var submitted by rememberSaveable { mutableStateOf(false) }
    var showService by rememberSaveable { mutableStateOf(false) }

    val nameError = if (submitted && name.isBlank()) "Brand / client name is required" else null
    val phoneError = when {
        !submitted -> null
        phone.isBlank() -> "WhatsApp number is required"
        !Phone.isValid(phone) -> "Enter a valid number (8-15 digits, include country code)"
        else -> null
    }
    val serviceError = if (submitted && service == null) "Please choose a service" else null

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(if (existing == null) "Add Client" else "Edit Client", subtitle = "SUNDRA EDITS", onBack = onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).imePadding().padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    GlassField(name, { name = it }, "Brand / Client Name *", capitalization = KeyboardCapitalization.Words, error = nameError)
                    GlassField(phone, { phone = it }, "WhatsApp Number *", keyboardType = KeyboardType.Phone, error = phoneError)
                    GlassField(instagram, { instagram = it }, "Instagram Username (optional)")
                    GlassField(city, { city = it }, "City (optional)", capitalization = KeyboardCapitalization.Words)
                    ClickField("Service Category *", service?.label ?: "", { showService = true }, error = serviceError)
                    DateField("Contact Date", contactDate, { it?.let { d -> contactDate = d } })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(messageSent, { messageSent = it }, colors = glassCheckboxColors())
                        Text("Message Sent \u2713")
                    }
                    if (existing == null) {
                        DateField("Follow-up date (optional)", followUp, { followUp = it }, clearable = true)
                    }
                    GlassField(notes, { notes = it }, "Notes (optional)", singleLine = false, minLines = 4, capitalization = KeyboardCapitalization.Sentences)
                }
            }
            GoldButton(
                if (existing == null) "Save Client" else "Save Changes",
                onClick = {
                    submitted = true
                    val s = service
                    if (name.isNotBlank() && Phone.isValid(phone) && s != null) {
                        val draft = (existing ?: Client(name = "", phone = "", contactDate = contactDate)).copy(
                            name = name.trim(),
                            phone = phone.trim(),
                            instagram = Phone.cleanInstagram(instagram),
                            city = city.trim(),
                            service = s,
                            contactDate = contactDate,
                            messageSent = messageSent,
                            notes = notes.trim()
                        )
                        if (existing == null) vm.addClient(draft, followUp) { id -> onSaved(id) }
                        else vm.updateClient(existing, draft) { onSaved(existing.id) }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                icon = Icons.Default.Check
            )
            Spacer(Modifier.height(24.dp).navigationBarsPadding())
        }
    }

    if (showService) {
        PickerSheet(
            title = "Service Category",
            options = Service.values().toList(),
            selected = service,
            label = { it.label },
            subtitle = { it.tagline },
            tint = { when (it) { Service.SOCIAL -> Sage; Service.VIDEO -> Cream; Service.WEB -> Champagne } },
            onPick = { service = it; showService = false },
            onDismiss = { showService = false }
        )
    }
}
