@file:OptIn(ExperimentalMaterial3Api::class)

package com.sundraedits.crm.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sundraedits.crm.data.Client
import com.sundraedits.crm.data.ClientStatus
import com.sundraedits.crm.util.Dates

/** Cream background with soft decorative gradient glows. */
@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Ivory, Cream)))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val c1 = Offset(w * 0.95f, h * 0.05f)
            drawCircle(Brush.radialGradient(listOf(Champagne.copy(alpha = 0.75f), Color.Transparent), center = c1, radius = w * 0.85f), radius = w * 0.85f, center = c1)
            val c2 = Offset(w * 0.0f, h * 0.55f)
            drawCircle(Brush.radialGradient(listOf(Sage.copy(alpha = 0.95f), Color.Transparent), center = c2, radius = w * 0.9f), radius = w * 0.9f, center = c2)
            val c3 = Offset(w * 0.9f, h * 0.95f)
            drawCircle(Brush.radialGradient(listOf(Gold.copy(alpha = 0.18f), Color.Transparent), center = c3, radius = w * 0.8f), radius = w * 0.8f, center = c3)
        }
        content()
    }
}

/** Reusable frosted-glass surface: translucent fill, white border, inner highlight, soft shadow. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    corner: Dp = 24.dp,
    tint: Color = Color.Transparent,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(corner)
    var m = modifier
        .shadow(10.dp, shape, ambientColor = Taupe.copy(alpha = 0.25f), spotColor = Taupe.copy(alpha = 0.25f))
        .clip(shape)
        .background(tint.copy(alpha = 0.55f))
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.72f), Color.White.copy(alpha = 0.42f))))
        .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.95f), Color.White.copy(alpha = 0.3f))), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Box(m) {
        Box(
            Modifier.matchParentSize().background(
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.35f), Color.Transparent), start = Offset.Zero, end = Offset(500f, 500f))
            )
        )
        Column(Modifier.padding(contentPadding), content = content)
    }
}

@Composable
fun GlassBottomBar(current: String?, onNavigate: (String) -> Unit, onAdd: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(34.dp)
    Box(modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(
            Modifier.fillMaxWidth()
                .shadow(16.dp, shape, ambientColor = Taupe.copy(alpha = 0.3f), spotColor = Taupe.copy(alpha = 0.3f))
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.88f), Ivory.copy(alpha = 0.78f))))
                .border(1.dp, Brush.verticalGradient(listOf(Color.White, Color.White.copy(alpha = 0.35f))), shape)
                .padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            NavSlot("Home", Icons.Default.Home, current == Routes.DASH) { onNavigate(Routes.DASH) }
            NavSlot("Clients", Icons.Default.Person, current == Routes.CLIENTS) { onNavigate(Routes.CLIENTS) }
            Box(
                Modifier.size(54.dp)
                    .shadow(8.dp, CircleShape)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Champagne, Gold)))
                    .clickable(onClick = onAdd),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Add, contentDescription = "Add client", tint = Color.White) }
            NavSlot("Follow-ups", Icons.Default.Notifications, current == Routes.FOLLOWUPS) { onNavigate(Routes.FOLLOWUPS) }
            NavSlot("Projects", Icons.Default.CheckCircle, current == Routes.PROJECTS) { onNavigate(Routes.PROJECTS) }
        }
    }
}

@Composable
private fun NavSlot(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(22.dp))
            .background(if (selected) Champagne.copy(alpha = 0.55f) else Color.Transparent)
            .clickable(onClick = onClick)
            .defaultMinSize(minWidth = 56.dp, minHeight = 48.dp)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) Gold else Taupe, modifier = Modifier.size(22.dp))
        Text(label, fontSize = 10.sp, color = if (selected) Gold else Taupe, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
    }
}

@Composable
fun ScreenHeader(
    title: String,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Ink) }
        } else {
            Spacer(Modifier.width(4.dp))
        }
        Column(Modifier.weight(1f)) {
            if (subtitle != null) Text(subtitle, fontSize = 11.sp, letterSpacing = 2.sp, color = Gold, fontWeight = FontWeight.SemiBold)
            Text(title, style = MaterialTheme.typography.headlineMedium, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        actions()
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier.padding(top = 8.dp), style = MaterialTheme.typography.titleLarge, color = Ink)
}

@Composable
fun GoldButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 52.dp),
        enabled = enabled,
        shape = RoundedCornerShape(20.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.White)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SoftButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, danger: Boolean = false) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 48.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Champagne.copy(alpha = 0.5f), contentColor = if (danger) Danger else Ink)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Round 44dp icon action. */
@Composable
fun RoundAction(icon: ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Champagne.copy(alpha = 0.5f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, contentDescription = description, tint = Ink, modifier = Modifier.size(20.dp)) }
}

@Composable
fun TextPill(text: String, onClick: () -> Unit) {
    Box(
        Modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(22.dp)).background(Champagne.copy(alpha = 0.5f)).clickable(onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Ink, fontWeight = FontWeight.Medium, fontSize = 14.sp) }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(text, maxLines = 1) },
        colors = FilterChipDefaults.filterChipColors(
            containerColor = Color.White.copy(alpha = 0.5f),
            labelColor = Ink,
            selectedContainerColor = Champagne,
            selectedLabelColor = Ink
        )
    )
}

@Composable
fun StatusChip(s: ClientStatus) {
    val (bg, fg) = when (s) {
        ClientStatus.CONTACTED -> Cream to Taupe
        ClientStatus.REPLY_RECEIVED -> Sage to Ink
        ClientStatus.WORK_DISCUSSION -> Champagne to Ink
        ClientStatus.CONFIRMED -> Gold to Color.White
        ClientStatus.COMPLETED -> Taupe to Color.White
        ClientStatus.CLOSED -> Color.White.copy(alpha = 0.7f) to Taupe
    }
    Text(
        s.label, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
fun EmptyState(text: String, modifier: Modifier = Modifier) {
    GlassCard(modifier.fillMaxWidth()) {
        Text(text, color = Taupe, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
    }
}

@Composable
fun LoadingBox() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier, accent: Color = Ink) {
    GlassCard(modifier, contentPadding = PaddingValues(14.dp)) {
        Text(value, style = MaterialTheme.typography.headlineMedium, color = accent)
        Text(label, fontSize = 12.sp, color = Taupe)
    }
}

@Composable
fun ClientMini(c: Client, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), onClick = onClick, contentPadding = PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(c.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${c.service.short} \u00B7 ${Dates.date(c.contactDate)}", fontSize = 12.sp, color = Taupe)
            }
            Spacer(Modifier.width(8.dp))
            StatusChip(c.status)
        }
    }
}

@Composable
fun glassCheckboxColors() = CheckboxDefaults.colors(checkedColor = Gold, uncheckedColor = Taupe, checkmarkColor = Color.White)

@Composable
fun GlassField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
    capitalization: KeyboardCapitalization = KeyboardCapitalization.None,
    singleLine: Boolean = true,
    minLines: Int = 1,
    error: String? = null,
    readOnly: Boolean = false,
    trailing: @Composable (() -> Unit)? = null
) {
    val support: (@Composable () -> Unit)? = if (error != null) {
        { Text(error) }
    } else null
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = singleLine,
        minLines = minLines,
        readOnly = readOnly,
        isError = error != null,
        supportingText = support,
        trailingIcon = trailing,
        shape = RoundedCornerShape(18.dp),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, capitalization = capitalization),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color.White.copy(alpha = 0.55f),
            unfocusedContainerColor = Color.White.copy(alpha = 0.35f),
            focusedBorderColor = Gold,
            unfocusedBorderColor = Champagne,
            focusedLabelColor = Gold,
            unfocusedLabelColor = Taupe,
            cursorColor = Gold,
            focusedTextColor = Ink,
            unfocusedTextColor = Ink,
            errorContainerColor = Color.White.copy(alpha = 0.45f)
        )
    )
}

/** Read-only field that opens something (picker, sheet, date dialog) when tapped. */
@Composable
fun ClickField(label: String, text: String, onClick: () -> Unit, error: String? = null, trailing: @Composable (() -> Unit)? = null, clickEndInset: Dp = 0.dp) {
    val trailingIcon: @Composable () -> Unit = trailing ?: { Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Gold) }
    Box(Modifier.fillMaxWidth()) {
        GlassField(
            value = text, onValueChange = {}, label = label, readOnly = true, error = error,
            trailing = trailingIcon
        )
        Box(Modifier.matchParentSize().padding(end = clickEndInset).clickable(onClick = onClick))
    }
}

@Composable
fun DateField(label: String, value: Long?, onChange: (Long?) -> Unit, modifier: Modifier = Modifier, clearable: Boolean = false) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        ClickField(
            label = label,
            text = value?.let { Dates.date(it) } ?: "",
            onClick = { open = true },
            clickEndInset = if (clearable && value != null) 56.dp else 0.dp,
            trailing = {
                if (clearable && value != null) {
                    IconButton(onClick = { onChange(null) }) { Icon(Icons.Default.Close, contentDescription = "Clear date", tint = Taupe) }
                } else {
                    Icon(Icons.Default.DateRange, contentDescription = null, tint = Gold)
                }
            }
        )
    }
    if (open) {
        val state = rememberDatePickerState(initialSelectedDateMillis = Dates.toPickerMillis(value ?: Dates.today()))
        DatePickerDialog(
            onDismissRequest = { open = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { onChange(Dates.fromPickerMillis(it)) }
                    open = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { open = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }
}

/** Generic glass bottom-sheet selector used for services and statuses. */
@Composable
fun <T> PickerSheet(
    title: String,
    options: List<T>,
    selected: T?,
    label: (T) -> String,
    onPick: (T) -> Unit,
    onDismiss: () -> Unit,
    subtitle: (T) -> String? = { null },
    tint: (T) -> Color = { Color.Transparent }
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Ivory
    ) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.headlineSmall, color = Ink)
            options.forEach { opt ->
                GlassCard(Modifier.fillMaxWidth(), onClick = { onPick(opt) }, tint = tint(opt)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(label(opt), fontWeight = FontWeight.SemiBold, color = Ink)
                            subtitle(opt)?.let { Text(it, fontSize = 12.sp, color = Taupe) }
                        }
                        if (opt == selected) Icon(Icons.Default.Check, contentDescription = "Selected", tint = Gold)
                    }
                }
            }
        }
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirmLabel: String, onConfirm: () -> Unit, onDismiss: () -> Unit, danger: Boolean = false) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ivory,
        title = { Text(title, color = Ink) },
        text = { Text(text, color = Ink) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirmLabel, color = if (danger) Danger else Gold, fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Taupe) } }
    )
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Text(label, color = Taupe, fontSize = 13.sp, modifier = Modifier.width(112.dp))
        Text(value, color = Ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
    }
}

val ListPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 120.dp)
