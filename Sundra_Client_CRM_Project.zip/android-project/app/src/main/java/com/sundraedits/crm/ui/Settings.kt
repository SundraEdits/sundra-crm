package com.sundraedits.crm.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.sundraedits.crm.util.Dates

@Composable
fun SettingsScreen(vm: CrmViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cc by vm.countryCode.collectAsState()
    val pending by vm.pendingRestore.collectAsState()
    var ccInput by remember(cc) { mutableStateOf(cc) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportTo(uri)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.readBackup(uri)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Settings", subtitle = "BACKUP & PREFERENCES", onBack = onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = ListPadding, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { SectionTitle("Backup") }
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Text("Your data lives only on this phone. Export a backup regularly and keep it somewhere safe.", fontSize = 13.sp, color = Taupe)
                    Column(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        GoldButton("Export Backup (JSON)", { exportLauncher.launch("sundra_crm_backup_${Dates.stamp()}.json") }, Modifier.fillMaxWidth(), Icons.Default.Send)
                        SoftButton("Share Backup", {
                            vm.prepareShare { file ->
                                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/json"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                ctx.startActivity(Intent.createChooser(send, "Share backup"))
                            }
                        }, Modifier.fillMaxWidth(), Icons.Default.Share)
                        SoftButton("Restore Backup", { importLauncher.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth(), Icons.Default.Refresh)
                    }
                }
            }
            item { SectionTitle("WhatsApp") }
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Text("Default country code is added to numbers saved without a + (for example 91 for India).", fontSize = 13.sp, color = Taupe)
                    Column(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassField(ccInput, { ccInput = it.filter { ch -> ch.isDigit() }.take(4) }, "Default country code (digits only)", keyboardType = KeyboardType.Number)
                        SoftButton("Save country code", { vm.setCountryCode(ccInput) }, Modifier.fillMaxWidth())
                    }
                }
            }
            item { SectionTitle("About") }
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Text("SUNDRA EDITS \u2014 Client CRM", fontSize = 15.sp)
                    Text("Version 1.0.0 \u00B7 Offline-first. No account, no internet permission.", fontSize = 12.sp, color = Taupe)
                }
            }
        }
    }

    val data = pending
    if (data != null) {
        ConfirmDialog(
            title = "Replace all data?",
            text = "This backup contains ${data.clients.size} clients, ${data.followUps.size} follow-ups and ${data.activities.size} activity entries. Restoring REPLACES everything currently in the app. A safety copy of your current data is saved inside the app first, but we recommend exporting a backup now if unsure.",
            confirmLabel = "Replace & Restore",
            onConfirm = { vm.confirmRestore() },
            onDismiss = { vm.cancelRestore() },
            danger = true
        )
    }
}
