package com.sundraedits.crm.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

object Routes {
    const val DASH = "dashboard"
    const val CLIENTS = "clients"
    const val FOLLOWUPS = "followups"
    const val PROJECTS = "projects"
    const val ADD = "add"
    const val EDIT = "edit/{id}"
    const val DETAIL = "detail/{id}"
    const val SETTINGS = "settings"
}

@Composable
fun CrmApp(vm: CrmViewModel = viewModel()) {
    val nav = rememberNavController()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val isMain = route == Routes.DASH || route == Routes.CLIENTS || route == Routes.FOLLOWUPS || route == Routes.PROJECTS
    val idArg = listOf(navArgument("id") { type = NavType.LongType })

    GlassBackground {
        NavHost(nav, startDestination = Routes.DASH, modifier = Modifier.fillMaxSize()) {
            composable(Routes.DASH) {
                DashboardScreen(vm, onAdd = { nav.navigate(Routes.ADD) }, onOpen = { nav.navigate("detail/$it") }, onSettings = { nav.navigate(Routes.SETTINGS) })
            }
            composable(Routes.CLIENTS) {
                ClientsScreen(vm, onOpen = { nav.navigate("detail/$it") }, onEdit = { nav.navigate("edit/$it") })
            }
            composable(Routes.FOLLOWUPS) { FollowUpsScreen(vm, onOpen = { nav.navigate("detail/$it") }) }
            composable(Routes.PROJECTS) { ProjectsScreen(vm, onOpen = { nav.navigate("detail/$it") }) }
            composable(Routes.ADD) {
                ClientFormScreen(vm, null, onBack = { nav.popBackStack() }, onSaved = { id ->
                    nav.navigate("detail/$id") { popUpTo(Routes.ADD) { inclusive = true } }
                })
            }
            composable(Routes.EDIT, arguments = idArg) {
                ClientFormScreen(vm, it.arguments?.getLong("id"), onBack = { nav.popBackStack() }, onSaved = { nav.popBackStack() })
            }
            composable(Routes.DETAIL, arguments = idArg) {
                val id = it.arguments?.getLong("id") ?: 0L
                DetailScreen(vm, id, onBack = { nav.popBackStack() }, onEdit = { nav.navigate("edit/$id") })
            }
            composable(Routes.SETTINGS) { SettingsScreen(vm, onBack = { nav.popBackStack() }) }
        }
        if (isMain) {
            GlassBottomBar(
                current = route,
                onNavigate = { r ->
                    nav.navigate(r) {
                        popUpTo(Routes.DASH) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                onAdd = { nav.navigate(Routes.ADD) },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
        SnackbarHost(
            snack,
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = if (isMain) 96.dp else 16.dp, start = 16.dp, end = 16.dp)
        ) { data ->
            Snackbar(data, shape = RoundedCornerShape(18.dp), containerColor = Taupe, contentColor = Color.White)
        }
    }
}
