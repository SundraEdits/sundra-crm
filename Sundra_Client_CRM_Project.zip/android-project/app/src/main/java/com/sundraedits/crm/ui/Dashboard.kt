package com.sundraedits.crm.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sundraedits.crm.data.Client
import com.sundraedits.crm.data.ClientStatus
import com.sundraedits.crm.data.FollowUp
import com.sundraedits.crm.util.Dates

enum class Period(val label: String) { WEEK("This week"), MONTH("This month"), ALL("All time") }

private val ActiveStatuses = setOf(ClientStatus.CONTACTED, ClientStatus.REPLY_RECEIVED, ClientStatus.WORK_DISCUSSION)

@Composable
fun DashboardScreen(vm: CrmViewModel, onAdd: () -> Unit, onOpen: (Long) -> Unit, onSettings: () -> Unit) {
    val clients by vm.clients.collectAsState()
    val followUps by vm.followUps.collectAsState()
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Client CRM", subtitle = "SUNDRA EDITS") {
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Ink) }
        }
        val list = clients
        if (list == null) LoadingBox() else DashboardContent(list, followUps, onAdd, onOpen)
    }
}

@Composable
private fun DashboardContent(list: List<Client>, followUps: List<FollowUp>, onAdd: () -> Unit, onOpen: (Long) -> Unit) {
    var period by rememberSaveable { mutableStateOf(Period.ALL) }
    val todayKey = Dates.todayKey()
    val pending = followUps.filter { !it.completed }
    val todays = pending.filter { Dates.dayKey(it.dueDate) == todayKey }
    val overdue = pending.filter { Dates.dayKey(it.dueDate) < todayKey }
    val byId = list.associateBy { it.id }
    val active = list.filter { it.status in ActiveStatuses }
    val confirmed = list.filter { it.status == ClientStatus.CONFIRMED }

    val stats = listOf(
        "Total clients" to list.size,
        "Messages sent" to list.count { it.messageSent },
        "Replies received" to list.count { it.repliedAt != null },
        "Active leads" to active.size,
        "Confirmed clients" to confirmed.size,
        "Completed projects" to list.count { it.status == ClientStatus.COMPLETED },
        "Today's follow-ups" to todays.size,
        "Overdue follow-ups" to overdue.size
    )

    LazyColumn(Modifier.fillMaxSize(), contentPadding = ListPadding, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { GoldButton("Add Client", onAdd, Modifier.fillMaxWidth(), icon = Icons.Default.Add) }
        items(stats.chunked(2)) { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { (label, value) ->
                    val accent = if (label == "Overdue follow-ups" && value > 0) Danger else if (label == "Today's follow-ups" && value > 0) Gold else Ink
                    StatCard(label, value.toString(), Modifier.weight(1f), accent)
                }
            }
        }

        item { SectionTitle("Analytics") }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Period.values().forEach { p -> Chip(p.label, period == p) { period = p } }
                }
                val start = when (period) {
                    Period.ALL -> null
                    Period.WEEK -> Dates.weekStart()
                    Period.MONTH -> Dates.monthStart()
                }
                val sel = if (start == null) list else list.filter { it.contactDate >= start }
                val outreach = sel.count { it.messageSent }
                val replies = sel.count { it.repliedAt != null }
                val confirmedEver = sel.count { it.confirmedAt != null }
                val replyRate = if (outreach == 0) 0 else (replies * 100f / outreach).coerceAtMost(100f).toInt()
                val conversion = if (outreach == 0) 0 else (confirmedEver * 100f / outreach).coerceAtMost(100f).toInt()
                Column(Modifier.padding(top = 12.dp)) {
                    InfoRow("Total outreach", outreach.toString())
                    InfoRow("Replies", replies.toString())
                    InfoRow("Reply rate", "$replyRate%")
                    InfoRow("Active leads", sel.count { it.status in ActiveStatuses }.toString())
                    InfoRow("Confirmed", confirmedEver.toString())
                    InfoRow("Completed", sel.count { it.status == ClientStatus.COMPLETED }.toString())
                    InfoRow("Conversion rate", "$conversion%")
                }
            }
        }

        item { SectionTitle("Today's Follow-ups") }
        if (todays.isEmpty()) item { EmptyState("Nothing due today") }
        items(todays, key = { "t${it.id}" }) { f ->
            val c = byId[f.clientId]
            if (c != null) GlassCard(Modifier.fillMaxWidth(), onClick = { onOpen(c.id) }, contentPadding = PaddingValues(14.dp)) {
                Text(c.name, fontWeight = FontWeight.SemiBold)
                if (f.notes.isNotBlank()) Text(f.notes, fontSize = 12.sp, color = Taupe)
            }
        }

        item { SectionTitle("Recent Clients") }
        if (list.isEmpty()) item { EmptyState("No clients yet. Tap Add Client to save your first one.") }
        items(list.sortedByDescending { it.createdAt }.take(5), key = { "r${it.id}" }) { ClientMini(it) { onOpen(it.id) } }

        item { SectionTitle("Active Leads") }
        if (active.isEmpty()) item { EmptyState("No active leads") }
        items(active.sortedByDescending { it.updatedAt }.take(5), key = { "a${it.id}" }) { ClientMini(it) { onOpen(it.id) } }

        item { SectionTitle("Confirmed Projects") }
        if (confirmed.isEmpty()) item { EmptyState("No confirmed projects yet") }
        items(confirmed.take(5), key = { "c${it.id}" }) { ClientMini(it) { onOpen(it.id) } }
    }
}
