package com.sundraedits.crm.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale

object Dates {
    private val zone: ZoneId get() = ZoneId.systemDefault()

    fun toLocalDate(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
    fun fromLocalDate(d: LocalDate): Long = d.atStartOfDay(zone).toInstant().toEpochMilli()
    fun today(): Long = fromLocalDate(LocalDate.now())
    fun tomorrow(): Long = fromLocalDate(LocalDate.now().plusDays(1))
    fun dayKey(ms: Long): Long = toLocalDate(ms).toEpochDay()
    fun todayKey(): Long = LocalDate.now().toEpochDay()
    fun weekStart(): Long = fromLocalDate(LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)))
    fun monthStart(): Long = fromLocalDate(LocalDate.now().withDayOfMonth(1))

    // Material DatePicker works in UTC midnight millis.
    fun toPickerMillis(ms: Long): Long = toLocalDate(ms).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    fun fromPickerMillis(ms: Long): Long = fromLocalDate(Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate())

    fun date(ms: Long): String =
        DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.getDefault()).format(Instant.ofEpochMilli(ms).atZone(zone))

    fun dateTime(ms: Long): String =
        DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Instant.ofEpochMilli(ms).atZone(zone))

    fun stamp(): String = DateTimeFormatter.ofPattern("yyyyMMdd_HHmm").format(LocalDateTime.now())
}

object Phone {
    fun isValid(raw: String): Boolean {
        val t = raw.trim()
        val digits = t.count { it.isDigit() }
        return digits in 8..15 && t.all { it.isDigit() || it in " +-()." }
    }

    /** Digits-only international number for wa.me links. */
    fun waDigits(raw: String, countryCode: String): String {
        val t = raw.trim()
        val digits = t.filter { it.isDigit() }
        if (t.startsWith("+")) return digits
        if (digits.startsWith("00")) return digits.drop(2)
        val cc = countryCode.filter { it.isDigit() }
        if (cc.isNotEmpty() && digits.length <= 10) return cc + digits.trimStart('0')
        return digits
    }

    fun cleanInstagram(raw: String): String {
        var s = raw.trim().substringBefore('?').trimEnd('/')
        s = s.substringAfterLast('/').removePrefix("@")
        return s.filter { !it.isWhitespace() }
    }
}

object Launch {
    private fun start(ctx: Context, intent: Intent, error: String) {
        try {
            ctx.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(ctx, error, Toast.LENGTH_SHORT).show()
        }
    }

    fun whatsApp(ctx: Context, phone: String, countryCode: String) {
        val digits = Phone.waDigits(phone, countryCode)
        start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits")), "Could not open WhatsApp")
    }

    fun dial(ctx: Context, phone: String) {
        val num = phone.filter { it.isDigit() || it == '+' }
        start(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")), "No dialer available")
    }

    fun instagram(ctx: Context, user: String) {
        start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/$user")), "Could not open Instagram")
    }
}
