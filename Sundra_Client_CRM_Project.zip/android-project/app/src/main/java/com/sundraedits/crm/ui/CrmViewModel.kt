package com.sundraedits.crm.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sundraedits.crm.data.Activity
import com.sundraedits.crm.data.BackupData
import com.sundraedits.crm.data.Client
import com.sundraedits.crm.data.ClientStatus
import com.sundraedits.crm.data.CrmDatabase
import com.sundraedits.crm.data.FollowUp
import com.sundraedits.crm.data.ProjectStatus
import com.sundraedits.crm.data.Repository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class CrmViewModel(app: Application) : AndroidViewModel(app) {
    private val db = CrmDatabase.get(app)
    private val dao = db.dao()
    private val repo = Repository(db)
    private val prefs = app.getSharedPreferences("crm_prefs", Context.MODE_PRIVATE)

    /** null = still loading */
    val clients: StateFlow<List<Client>?> = dao.clients().stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val followUps: StateFlow<List<FollowUp>> = dao.followUps().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val activities: StateFlow<List<Activity>> = dao.activities().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val countryCode = MutableStateFlow(prefs.getString("cc", "") ?: "")
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val pendingRestore = MutableStateFlow<BackupData?>(null)

    private fun op(okMessage: String? = null, block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
                okMessage?.let { messages.tryEmit(it) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                messages.tryEmit("Something went wrong: ${e.message}")
            }
        }
    }

    fun addClient(c: Client, followUp: Long?, onDone: (Long) -> Unit) {
        viewModelScope.launch {
            try {
                val id = repo.addClient(c, followUp)
                messages.tryEmit("Client saved")
                onDone(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                messages.tryEmit("Could not save client: ${e.message}")
            }
        }
    }

    fun updateClient(old: Client, new: Client, onDone: () -> Unit) {
        viewModelScope.launch {
            try {
                repo.updateClient(old, new)
                messages.tryEmit("Changes saved")
                onDone()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                messages.tryEmit("Could not save changes: ${e.message}")
            }
        }
    }

    fun saveNotes(id: Long, notes: String) = op("Notes saved") { repo.updateNotes(id, notes) }
    fun changeStatus(id: Long, s: ClientStatus) = op("Status updated") { repo.changeStatus(id, s) }
    fun deleteClient(id: Long) = op("Client deleted") { repo.deleteClient(id) }
    fun addFollowUp(clientId: Long, due: Long, notes: String) = op("Follow-up added") { repo.addFollowUp(clientId, due, notes) }
    fun setFollowUpDone(f: FollowUp, done: Boolean) = op(if (done) "Follow-up completed" else "Follow-up reopened") { repo.setFollowUpDone(f, done) }
    fun deleteFollowUp(f: FollowUp) = op("Follow-up deleted") { repo.deleteFollowUp(f) }
    fun updateProject(id: Long, amount: String, notes: String, ps: ProjectStatus) =
        op("Project updated") { repo.updateProject(id, amount, notes, ps) }

    fun setCountryCode(value: String) {
        val v = value.filter { it.isDigit() }.take(4)
        prefs.edit().putString("cc", v).apply()
        countryCode.value = v
        messages.tryEmit(if (v.isEmpty()) "Default country code cleared" else "Default country code set to +$v")
    }

    // ---------- Backup ----------

    fun exportTo(uri: Uri) = op("Backup exported") {
        val json = repo.exportJson()
        withContext(Dispatchers.IO) {
            val out = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                ?: throw IllegalStateException("Could not open the chosen file")
            out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
        }
    }

    fun prepareShare(onReady: (File) -> Unit) {
        viewModelScope.launch {
            try {
                val json = repo.exportJson()
                val file = withContext(Dispatchers.IO) {
                    val dir = File(getApplication<Application>().cacheDir, "backups").apply { mkdirs() }
                    File(dir, "sundra_crm_backup.json").also { it.writeText(json, Charsets.UTF_8) }
                }
                onReady(file)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                messages.tryEmit("Could not prepare backup: ${e.message}")
            }
        }
    }

    fun readBackup(uri: Uri) {
        viewModelScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openInputStream(uri)
                        ?.use { it.readBytes().toString(Charsets.UTF_8) }
                        ?: throw IllegalStateException("Could not open the chosen file")
                }
                pendingRestore.value = repo.parseBackup(text)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                messages.tryEmit("Invalid backup file: ${e.message}")
            }
        }
    }

    fun cancelRestore() {
        pendingRestore.value = null
    }

    fun confirmRestore() {
        val data = pendingRestore.value ?: return
        pendingRestore.value = null
        op("Backup restored: ${data.clients.size} clients") {
            // Safety snapshot of current data before it is replaced.
            val snapshot = repo.exportJson()
            withContext(Dispatchers.IO) {
                File(getApplication<Application>().filesDir, "pre_restore_backup.json").writeText(snapshot, Charsets.UTF_8)
            }
            repo.restore(data)
        }
    }
}
