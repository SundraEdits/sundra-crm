package com.sundraedits.crm.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CrmDao {
    @Query("SELECT * FROM clients ORDER BY contactDate DESC, id DESC")
    fun clients(): Flow<List<Client>>

    @Query("SELECT * FROM followups")
    fun followUps(): Flow<List<FollowUp>>

    @Query("SELECT * FROM activities ORDER BY timestamp DESC, id DESC")
    fun activities(): Flow<List<Activity>>

    @Query("SELECT * FROM clients WHERE id = :id")
    suspend fun getClient(id: Long): Client?

    @Query("SELECT * FROM clients")
    suspend fun allClientsOnce(): List<Client>

    @Query("SELECT * FROM followups")
    suspend fun allFollowUpsOnce(): List<FollowUp>

    @Query("SELECT * FROM activities")
    suspend fun allActivitiesOnce(): List<Activity>

    @Insert
    suspend fun insertClient(client: Client): Long

    @Update
    suspend fun updateClient(client: Client)

    @Query("DELETE FROM clients WHERE id = :id")
    suspend fun deleteClientById(id: Long)

    @Insert
    suspend fun insertFollowUp(followUp: FollowUp): Long

    @Update
    suspend fun updateFollowUp(followUp: FollowUp)

    @Delete
    suspend fun deleteFollowUp(followUp: FollowUp)

    @Insert
    suspend fun insertActivity(activity: Activity)

    @Query("DELETE FROM activities")
    suspend fun clearActivities()

    @Query("DELETE FROM followups")
    suspend fun clearFollowUps()

    @Query("DELETE FROM clients")
    suspend fun clearClients()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClients(list: List<Client>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFollowUps(list: List<FollowUp>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivities(list: List<Activity>)
}

@Database(entities = [Client::class, FollowUp::class, Activity::class], version = 1, exportSchema = false)
abstract class CrmDatabase : RoomDatabase() {
    abstract fun dao(): CrmDao

    companion object {
        @Volatile
        private var instance: CrmDatabase? = null

        fun get(context: Context): CrmDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    CrmDatabase::class.java,
                    "sundra_crm.db"
                ).build().also { instance = it }
            }
    }
}
