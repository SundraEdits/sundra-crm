package com.sundraedits.crm.data

import androidx.room.withTransaction
import com.sundraedits.crm.util.Dates
import org.json.JSONArray
import org.json.JSONObject

data class BackupData(
    val clients: List<Client>,
    val followUps: List<FollowUp>,
    val activities: List<Activity>
)

class Repository(private val db: CrmDatabase) {
    private val dao = db.dao()

    private suspend fun log(clientId: Long, type: ActivityType, text: String, at: Long = System.currentTimeMillis()) {
        dao.insertActivity(Activity(clientId = clientId, type = type, description = text, timestamp = at))
    }

    suspend fun addClient(c: Client, followUpDate: Long?): Long {
        return db.withTransaction {
            val now = System.currentTimeMillis()
            val id = dao.insertClient(c.copy(id = 0, createdAt = now, updatedAt = now))
            log(id, ActivityType.CREATED, "Client created", now)
            if (c.messageSent) log(id, ActivityType.MESSAGE, "Message marked as sent", now)
            if (followUpDate != null) {
                dao.insertFollowUp(FollowUp(clientId = id, dueDate = followUpDate, createdAt = now))
                log(id, ActivityType.FOLLOWUP, "Follow-up scheduled for ${Dates.date(followUpDate)}", now)
            }
            id
        }
    }

    suspend fun updateClient(old: Client, new: Client) {
        db.withTransaction {
            val now = System.currentTimeMillis()
            dao.updateClient(new.copy(updatedAt = now))
            if (old.messageSent != new.messageSent) {
                log(old.id, ActivityType.MESSAGE, if (new.messageSent) "Message marked as sent" else "Message sent mark removed", now)
            }
            if (old.notes != new.notes) log(old.id, ActivityType.NOTES, "Notes updated", now)
            if (old.name != new.name || old.phone != new.phone || old.instagram != new.instagram ||
                old.city != new.city || old.service != new.service || old.contactDate != new.contactDate
            ) {
                log(old.id, ActivityType.UPDATED, "Client details updated", now)
            }
            Unit
        }
    }

    suspend fun updateNotes(id: Long, notes: String) {
        db.withTransaction {
            val c = dao.getClient(id)
            if (c != null && c.notes != notes) {
                val now = System.currentTimeMillis()
                dao.updateClient(c.copy(notes = notes, updatedAt = now))
                log(id, ActivityType.NOTES, "Notes updated", now)
            }
            Unit
        }
    }

    suspend fun changeStatus(id: Long, s: ClientStatus) {
        db.withTransaction {
            val c = dao.getClient(id)
            if (c != null && c.status != s) {
                val now = System.currentTimeMillis()
                var n = c.copy(status = s, updatedAt = now)
                var newlyReplied = false
                var newlyConfirmed = false
                if (s != ClientStatus.CONTACTED && s != ClientStatus.CLOSED && n.repliedAt == null) {
                    n = n.copy(repliedAt = now, messageSent = true)
                    newlyReplied = true
                }
                if ((s == ClientStatus.CONFIRMED || s == ClientStatus.COMPLETED) && n.confirmedAt == null) {
                    n = n.copy(confirmedAt = now)
                    newlyConfirmed = true
                }
                if (s == ClientStatus.CONFIRMED && n.projectStatus == ProjectStatus.COMPLETED) {
                    n = n.copy(projectStatus = ProjectStatus.IN_PROGRESS, completedAt = null)
                }
                if (s == ClientStatus.COMPLETED) {
                    n = n.copy(projectStatus = ProjectStatus.COMPLETED, completedAt = now)
                }
                dao.updateClient(n)
                log(id, ActivityType.STATUS, "Status changed: ${c.status.label} \u2192 ${s.label}", now)
                if (newlyReplied) log(id, ActivityType.REPLY, "Reply received", now)
                if (newlyConfirmed) log(id, ActivityType.PROJECT, "Project confirmed", now)
                if (s == ClientStatus.COMPLETED) log(id, ActivityType.PROJECT, "Project completed", now)
            }
            Unit
        }
    }

    suspend fun updateProject(id: Long, amount: String, notes: String, ps: ProjectStatus) {
        db.withTransaction {
            val c = dao.getClient(id)
            if (c != null) {
                val now = System.currentTimeMillis()
                var n = c.copy(projectAmount = amount, projectNotes = notes, projectStatus = ps, updatedAt = now)
                if (ps == ProjectStatus.COMPLETED && c.status != ClientStatus.COMPLETED) {
                    n = n.copy(status = ClientStatus.COMPLETED, completedAt = now)
                    log(id, ActivityType.STATUS, "Status changed: ${c.status.label} \u2192 ${ClientStatus.COMPLETED.label}", now)
                    log(id, ActivityType.PROJECT, "Project completed", now)
                } else if (ps != ProjectStatus.COMPLETED && c.projectStatus == ProjectStatus.COMPLETED) {
                    n = n.copy(
                        status = if (c.status == ClientStatus.COMPLETED) ClientStatus.CONFIRMED else c.status,
                        completedAt = null
                    )
                    log(id, ActivityType.PROJECT, "Project reopened: ${ps.label}", now)
                } else if (ps != c.projectStatus) {
                    log(id, ActivityType.PROJECT, "Project status: ${ps.label}", now)
                }
                dao.updateClient(n)
            }
            Unit
        }
    }

    suspend fun deleteClient(id: Long) = dao.deleteClientById(id)

    suspend fun addFollowUp(clientId: Long, due: Long, notes: String) {
        db.withTransaction {
            val now = System.currentTimeMillis()
            dao.insertFollowUp(FollowUp(clientId = clientId, dueDate = due, notes = notes, createdAt = now))
            log(clientId, ActivityType.FOLLOWUP, "Follow-up scheduled for ${Dates.date(due)}", now)
            Unit
        }
    }

    suspend fun setFollowUpDone(f: FollowUp, done: Boolean) {
        db.withTransaction {
            val now = System.currentTimeMillis()
            dao.updateFollowUp(f.copy(completed = done, completedAt = if (done) now else null))
            if (done) log(f.clientId, ActivityType.FOLLOWUP_DONE, "Follow-up completed (due ${Dates.date(f.dueDate)})", now)
            Unit
        }
    }

    suspend fun deleteFollowUp(f: FollowUp) = dao.deleteFollowUp(f)

    // ---------- Backup / restore ----------

    suspend fun exportJson(): String {
        val o = JSONObject()
        o.put("app", "SUNDRA EDITS CRM")
        o.put("version", 1)
        o.put("exportedAt", System.currentTimeMillis())
        val clients = JSONArray()
        dao.allClientsOnce().forEach { clients.put(it.toJson()) }
        val fus = JSONArray()
        dao.allFollowUpsOnce().forEach { fus.put(it.toJson()) }
        val acts = JSONArray()
        dao.allActivitiesOnce().forEach { acts.put(it.toJson()) }
        o.put("clients", clients)
        o.put("followUps", fus)
        o.put("activities", acts)
        return o.toString(2)
    }

    fun parseBackup(text: String): BackupData {
        val o = JSONObject(text)
        require(o.optString("app") == "SUNDRA EDITS CRM") { "This is not a SUNDRA EDITS CRM backup file." }
        val clients = o.getJSONArray("clients").let { a -> (0 until a.length()).map { clientFrom(a.getJSONObject(it)) } }
        val fus = o.optJSONArray("followUps")?.let { a -> (0 until a.length()).map { followUpFrom(a.getJSONObject(it)) } } ?: emptyList()
        val acts = o.optJSONArray("activities")?.let { a -> (0 until a.length()).map { activityFrom(a.getJSONObject(it)) } } ?: emptyList()
        val ids = clients.map { it.id }.toSet()
        return BackupData(clients, fus.filter { it.clientId in ids }, acts.filter { it.clientId in ids })
    }

    suspend fun restore(data: BackupData) {
        db.withTransaction {
            dao.clearActivities()
            dao.clearFollowUps()
            dao.clearClients()
            dao.insertClients(data.clients)
            dao.insertFollowUps(data.followUps)
            dao.insertActivities(data.activities)
        }
    }

    private fun Client.toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("phone", phone); put("instagram", instagram); put("city", city)
        put("service", service.name); put("contactDate", contactDate); put("messageSent", messageSent)
        put("status", status.name); put("notes", notes); put("createdAt", createdAt); put("updatedAt", updatedAt)
        put("repliedAt", repliedAt ?: JSONObject.NULL)
        put("confirmedAt", confirmedAt ?: JSONObject.NULL)
        put("completedAt", completedAt ?: JSONObject.NULL)
        put("projectAmount", projectAmount); put("projectNotes", projectNotes)
        put("projectStatus", projectStatus.name)
    }

    private fun FollowUp.toJson() = JSONObject().apply {
        put("id", id); put("clientId", clientId); put("dueDate", dueDate); put("notes", notes)
        put("completed", completed); put("completedAt", completedAt ?: JSONObject.NULL); put("createdAt", createdAt)
    }

    private fun Activity.toJson() = JSONObject().apply {
        put("id", id); put("clientId", clientId); put("type", type.name)
        put("description", description); put("timestamp", timestamp)
    }

    private fun JSONObject.longOrNull(k: String): Long? = if (has(k) && !isNull(k)) getLong(k) else null

    private inline fun <reified E : Enum<E>> enumOr(v: String, fallback: E): E =
        runCatching { enumValueOf<E>(v) }.getOrDefault(fallback)

    private fun clientFrom(o: JSONObject) = Client(
        id = o.getLong("id"),
        name = o.getString("name"),
        phone = o.optString("phone", ""),
        instagram = o.optString("instagram", ""),
        city = o.optString("city", ""),
        service = enumOr(o.optString("service"), Service.SOCIAL),
        contactDate = o.getLong("contactDate"),
        messageSent = o.optBoolean("messageSent", false),
        status = enumOr(o.optString("status"), ClientStatus.CONTACTED),
        notes = o.optString("notes", ""),
        createdAt = o.optLong("createdAt", 0),
        updatedAt = o.optLong("updatedAt", 0),
        repliedAt = o.longOrNull("repliedAt"),
        confirmedAt = o.longOrNull("confirmedAt"),
        completedAt = o.longOrNull("completedAt"),
        projectAmount = o.optString("projectAmount", ""),
        projectNotes = o.optString("projectNotes", ""),
        projectStatus = enumOr(o.optString("projectStatus"), ProjectStatus.PENDING)
    )

    private fun followUpFrom(o: JSONObject) = FollowUp(
        id = o.getLong("id"),
        clientId = o.getLong("clientId"),
        dueDate = o.getLong("dueDate"),
        notes = o.optString("notes", ""),
        completed = o.optBoolean("completed", false),
        completedAt = o.longOrNull("completedAt"),
        createdAt = o.optLong("createdAt", 0)
    )

    private fun activityFrom(o: JSONObject) = Activity(
        id = o.getLong("id"),
        clientId = o.getLong("clientId"),
        type = enumOr(o.optString("type"), ActivityType.UPDATED),
        description = o.optString("description", ""),
        timestamp = o.getLong("timestamp")
    )
}
