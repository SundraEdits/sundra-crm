package com.sundraedits.crm.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sundraedits.crm.data.FollowUp
import com.sundraedits.crm.util.Dates
import com.sundraedits.crm.util.Launch

@Composable
fun FollowUpsScreen(vm: CrmViewModel, onOpen: (Long) -> Unit) {
    val clients by vm.clients.collectAsState()
    val followUps by vm.followUps.collectAsState()
    val cc by vm.countryCode.collectAsState()
    val ctx = LocalContext.current

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Follow-ups", subtitle = "SUNDRA EDITS")
        val list = clients
        if (list == null) {
            LoadingBox()
        } else {
            val byId = list.associateBy { it.id }
            val t = Dates.todayKey()
            val pending = followUps.filter { !it.completed && byId.containsKey(it.clientId) }
            val overdue = pending.filter { Dates.dayKey(it.dueDate) < t }.sortedBy { it.dueDate }
            val today = pending.filter { Dates.dayKey(it.dueDate) == t }
            val upcoming = pending.filter { Dates.dayKey(it.dueDate) > t }.sortedBy { it.dueDate }
            val done = followUps.filter { it.completed && byId.containsKey(it.clientId) }.sortedByDescending { it.completedAt ?: 0L }

            @Composable
            fun card(f: FollowUp, accent: Color) {
                val c = byId[f.clientId]
                FollowUpCard(
                    f = f, clientName = c?.name, accent = accent,
                    onToggle = { vm.setFollowUpDone(f, !f.completed) },
                    onWhatsApp = c?.let { cl -> { Launch.whatsApp(ctx, cl.phone, cc) } },
                    onOpen = { onOpen(f.clientId) },
                    onDelete = { vm.deleteFollowUp(f) }
                )
            }

            LazyColumn(Modifier.fillMaxSize(), contentPadding = ListPadding, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (followUps.isEmpty()) item { EmptyState("No follow-ups yet. Add one from a client's profile or while adding a client.") }
                item { SectionTitle("Overdue (${overdue.size})") }
                if (overdue.isEmpty()) item { EmptyState("Nothing overdue") }
                items(overdue, key = { "o${it.id}" }) { card(it, Danger) }
                item { SectionTitle("Follow-up Today (${today.size})") }
                if (today.isEmpty()) item { EmptyState("Nothing due today") }
                items(today, key = { "t${it.id}" }) { card(it, Gold) }
                item { SectionTitle("Upcoming (${upcoming.size})") }
                if (upcoming.isEmpty()) item { EmptyState("No upcoming follow-ups") }
                items(upcoming, key = { "u${it.id}" }) { card(it, Taupe) }
                item { SectionTitle("Completed (${done.size})") }
                if (done.isEmpty()) item { EmptyState("No completed follow-ups yet") }
                items(done, key = { "d${it.id}" }) { card(it, Taupe) }
            }
        }
    }
}

@Composable
fun FollowUpCard(
    f: FollowUp,
    clientName: String?,
    accent: Color,
    onToggle: () -> Unit,
    onWhatsApp: (() -> Unit)?,
    onOpen: (() -> Unit)?,
    onDelete: () -> Unit
) {
    var confirmDelete by remember { mutableStateOf(false) }
    GlassCard(Modifier.fillMaxWidth(), onClick = onOpen, contentPadding = PaddingValues(start = 6.dp, end = 8.dp, top = 8.dp, bottom = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(f.completed, { onToggle() }, colors = glassCheckboxColors())
            Column(Modifier.weight(1f)) {
                if (clientName != null) {
                    Text(clientName, fontWeight = FontWeight.SemiBold, textDecoration = if (f.completed) TextDecoration.LineThrough else null)
                }
                Text(Dates.date(f.dueDate), color = accent, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                if (f.notes.isNotBlank()) Text(f.notes, fontSize = 12.sp, color = Taupe)
            }
            if (onWhatsApp != null) RoundAction(Icons.Default.Send, "Open WhatsApp", onWhatsApp)
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Close, contentDescription = "Delete follow-up", tint = Taupe, modifier = Modifier.size(20.dp)) }
        }
    }
    if (confirmDelete) {
        ConfirmDialog("Delete follow-up?", "This follow-up will be removed.", "Delete", { confirmDelete = false; onDelete() }, { confirmDelete = false }, danger = true)
    }
}

@Composable
fun AddFollowUpDialog(onAdd: (Long, String) -> Unit, onDismiss: () -> Unit) {
    var date by remember { mutableStateOf<Long?>(Dates.tomorrow()) }
    var notes by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ivory,
        title = { Text("Add Follow-up", color = Ink) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 4.dp)) {
                DateField("Follow-up date", date, { date = it ?: date })
                GlassField(notes, { notes = it }, "Follow-up notes", singleLine = false, minLines = 3)
            }
        },
        confirmButton = {
            TextButton(onClick = { date?.let { onAdd(it, notes.trim()) } }) { Text("Add", color = Gold, fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Taupe) } }
    )
}
