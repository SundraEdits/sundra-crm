package com.sundraedits.crm.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sundraedits.crm.data.Activity
import com.sundraedits.crm.data.Client
import com.sundraedits.crm.data.ClientStatus
import com.sundraedits.crm.data.FollowUp
import com.sundraedits.crm.util.Dates
import com.sundraedits.crm.util.Launch

@Composable
fun DetailScreen(vm: CrmViewModel, clientId: Long, onBack: () -> Unit, onEdit: () -> Unit) {
    val clients by vm.clients.collectAsState()
    val followUps by vm.followUps.collectAsState()
    val activities by vm.activities.collectAsState()
    val cc by vm.countryCode.collectAsState()
    val list = clients
    val client = list?.firstOrNull { it.id == clientId }
    when {
        list == null -> Column(Modifier.fillMaxSize()) { ScreenHeader("Client", onBack = onBack); LoadingBox() }
        client == null -> {
            // Client was deleted: leave this screen.
            LaunchedEffect(Unit) { onBack() }
            Box(Modifier.fillMaxSize())
        }
        else -> DetailContent(
            vm, client,
            followUps.filter { it.clientId == clientId }.sortedWith(compareBy<FollowUp> { it.completed }.thenBy { it.dueDate }),
            activities.filter { it.clientId == clientId },
            cc, onBack, onEdit
        )
    }
}

@Composable
private fun DetailContent(
    vm: CrmViewModel, c: Client, fus: List<FollowUp>, acts: List<Activity>,
    cc: String, onBack: () -> Unit, onEdit: () -> Unit
) {
    val ctx = LocalContext.current
    var showStatus by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var showFollowUp by remember { mutableStateOf(false) }
    var showProject by remember { mutableStateOf(false) }
    var notes by remember(c.notes) { mutableStateOf(c.notes) }
    val nextFu = fus.firstOrNull { !it.completed }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(c.name, subtitle = "CLIENT PROFILE", onBack = onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = ListPadding, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.service.short, color = Taupe, fontSize = 13.sp)
                        }
                        StatusChip(c.status)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        SoftButton("WhatsApp", { Launch.whatsApp(ctx, c.phone, cc) }, Modifier.weight(1f), Icons.Default.Send)
                        SoftButton("Call", { Launch.dial(ctx, c.phone) }, Modifier.weight(1f), Icons.Default.Call)
                    }
                    if (c.instagram.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        SoftButton("Instagram @${c.instagram}", { Launch.instagram(ctx, c.instagram) }, Modifier.fillMaxWidth())
                    }
                }
            }
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    InfoRow("WhatsApp", c.phone)
                    InfoRow("Instagram", if (c.instagram.isBlank()) "\u2014" else "@${c.instagram}")
                    InfoRow("City", c.city.ifBlank { "\u2014" })
                    InfoRow("Service", c.service.label)
                    InfoRow("Contact date", Dates.date(c.contactDate))
                    InfoRow("Message sent", if (c.messageSent) "Yes \u2713" else "No")
                    InfoRow("Status", c.status.label)
                    InfoRow("Next follow-up", nextFu?.let { Dates.date(it.dueDate) } ?: "\u2014")
                    InfoRow("Created", Dates.dateTime(c.createdAt))
                    InfoRow("Last updated", Dates.dateTime(c.updatedAt))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    SoftButton("Edit", onEdit, Modifier.weight(1f), Icons.Default.Edit)
                    SoftButton("Status", { showStatus = true }, Modifier.weight(1f), Icons.Default.Refresh)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    SoftButton("Follow-up", { showFollowUp = true }, Modifier.weight(1f), Icons.Default.Add)
                    SoftButton("Delete", { showDelete = true }, Modifier.weight(1f), Icons.Default.Delete, danger = true)
                }
            }

            item { SectionTitle("Notes") }
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    GlassField(notes, { notes = it }, "Notes", singleLine = false, minLines = 4)
                    if (notes != c.notes) {
                        Spacer(Modifier.height(8.dp))
                        GoldButton("Save Notes", { vm.saveNotes(c.id, notes.trim()) }, Modifier.fillMaxWidth())
                    }
                }
            }

            if (c.status == ClientStatus.CONFIRMED || c.status == ClientStatus.COMPLETED) {
                item { SectionTitle("Project") }
                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        InfoRow("Status", c.projectStatus.label)
                        InfoRow("Confirmed", c.confirmedAt?.let { Dates.date(it) } ?: "\u2014")
                        InfoRow("Amount", c.projectAmount.ifBlank { "\u2014" })
                        InfoRow("Notes", c.projectNotes.ifBlank { "\u2014" })
                        Spacer(Modifier.height(8.dp))
                        SoftButton("Edit Project", { showProject = true }, Modifier.fillMaxWidth(), Icons.Default.Edit)
                    }
                }
            }

            item { SectionTitle("Follow-ups") }
            if (fus.isEmpty()) item { EmptyState("No follow-ups for this client") }
            items(fus, key = { "f${it.id}" }) { f ->
                FollowUpCard(f, null, if (f.completed) Taupe else if (Dates.dayKey(f.dueDate) < Dates.todayKey()) Danger else Gold,
                    onToggle = { vm.setFollowUpDone(f, !f.completed) }, onWhatsApp = null, onOpen = null, onDelete = { vm.deleteFollowUp(f) })
            }

            item { SectionTitle("Activity History") }
            if (acts.isEmpty()) item { EmptyState("No activity yet") }
            items(acts, key = { "a${it.id}" }) { a ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Box(Modifier.padding(top = 6.dp).size(8.dp).clip(CircleShape).background(Gold))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(a.description, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text(Dates.dateTime(a.timestamp), fontSize = 12.sp, color = Taupe)
                    }
                }
            }
        }
    }

    if (showStatus) {
        PickerSheet(
            title = "Change Status",
            options = ClientStatus.values().toList(),
            selected = c.status,
            label = { it.label },
            tint = { when (it) { ClientStatus.CONFIRMED -> Champagne; ClientStatus.COMPLETED -> Sage; else -> Cream } },
            onPick = { vm.changeStatus(c.id, it); showStatus = false },
            onDismiss = { showStatus = false }
        )
    }
    if (showFollowUp) {
        AddFollowUpDialog(onAdd = { date, n -> vm.addFollowUp(c.id, date, n); showFollowUp = false }, onDismiss = { showFollowUp = false })
    }
    if (showProject) {
        ProjectDialog(c, { amt, n, ps -> vm.updateProject(c.id, amt, n, ps); showProject = false }, { showProject = false })
    }
    if (showDelete) {
        ConfirmDialog(
            title = "Delete ${c.name}?",
            text = "This permanently removes the client, their follow-ups and activity history. To keep the record, change the status to Closed / Not Interested instead.",
            confirmLabel = "Delete",
            onConfirm = { showDelete = false; vm.deleteClient(c.id) },
            onDismiss = { showDelete = false },
            danger = true
        )
    }
}
