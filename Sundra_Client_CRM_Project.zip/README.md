# SUNDRA EDITS — Client CRM (native Android)

Kotlin + Jetpack Compose + Material 3 + Room. Offline-first, no internet permission.
Premium cream "Liquid Glass" design. Original design inspired by glass interfaces.

> Status: the source was written and statically checked (XML validity, bracket balance),
> but it has NOT been compiled by the author. The first GitHub Actions run is the first real build.
> If it fails, open the failed run, download the "build-logs" artifact and send the error to be fixed.

## Project layout

    Sundra_Client_CRM_Project.zip
      README.md
      android-project/
        settings.gradle.kts, build.gradle.kts, gradle.properties
        gradle/wrapper/gradle-wrapper.properties
        app/build.gradle.kts
        app/src/main/AndroidManifest.xml
        app/src/main/java/com/sundraedits/crm/   (data/, util/, ui/)
        app/src/main/res/                        (icon, themes, file_paths)

Note: `gradlew` and `gradle-wrapper.jar` are binary files that could not be generated here.
The workflow installs Gradle 8.7 itself, so they are not needed for the GitHub build.
(Android Studio will create the wrapper automatically if you open the project there.)

## Build the APK with GitHub (beginner steps)

1. Create a free account at github.com and click **New repository**. Name it e.g. `sundra-crm`. Create it.
2. In the new repo click **Add file → Upload files**. Drag in `Sundra_Client_CRM_Project.zip` (do NOT unzip it). Click **Commit changes**.
3. Click **Add file → Create new file**. In the name box type exactly:
   `.github/workflows/build-apk.yml`
   (typing the slashes creates the folders). Paste the full contents of the separate `build-apk.yml` file. Click **Commit changes**.
   The workflow MUST live at `.github/workflows/build-apk.yml` — GitHub ignores it anywhere else, including inside the ZIP.
4. Open the **Actions** tab. If asked, click "I understand my workflows, enable them".
5. Pick **Build Sundra Client CRM APK** → **Run workflow** → **Run workflow**. (It also runs automatically when the ZIP or workflow is pushed.)
6. Wait about 5–10 minutes until the run shows a green check.
7. Open the run, scroll to **Artifacts**, download **SundraEditsCRM-debug-apk**, unzip it to get `SundraEditsCRM-debug.apk`.

## Install on your phone

1. Copy the APK to your phone.
2. Open it; allow "Install unknown apps" for your file manager/browser when asked.
3. Tap Install. This is a debug-signed APK, fine for personal use.

## Using the app

* **+** (center of the bottom bar) adds a client. The contact date fills in with today's date.
* Send your WhatsApp message manually first, then tick **Message Sent ✓**.
* Open a client to change status, add follow-ups, edit notes, or open WhatsApp/Call/Instagram.
* Settings (gear icon on Home): export / share / restore a JSON backup and set a default country code
  (e.g. `91`) so numbers saved without `+` still open correctly in WhatsApp.
* Restore always asks for confirmation and first saves a safety copy of current data inside the app.
